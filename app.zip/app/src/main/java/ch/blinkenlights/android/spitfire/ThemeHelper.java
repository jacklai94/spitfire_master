/*
*/

package ch.blinkenlights.android.spitfire;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.os.Build;

public class ThemeHelper {

	/**
	 * Calls context.setTheme() with given theme.
	 * Will automatically swap the theme with an alternative
	 * version if the user requested us to use it
	 */
	final public static void setTheme(Context context, int theme) {
		if (usesHoloTheme() == false) {
			TypedArray ar = null;

			switch (theme) {
				case R.style.Playback:
					ar = context.getResources().obtainTypedArray(R.array.theme_category_playback);
					break;
				case R.style.Library:
					ar = context.getResources().obtainTypedArray(R.array.theme_category_library);
					break;
				case R.style.BackActionBar:
					ar = context.getResources().obtainTypedArray(R.array.theme_category_backactionbar);
					break;
				case R.style.PopupDialog:
					ar = context.getResources().obtainTypedArray(R.array.theme_category_popupdialog);
					break;
				default:
					throw new IllegalArgumentException("setTheme() called with unknown theme!");
			}
			theme = ar.getResourceId(getSelectedThemeIndex(context), -1);
			ar.recycle();
		}

		context.setTheme(theme);
	}

	/**
	 * Helper function to get the correct play button drawable for our
	 * notification: The notification does not depend on the theme but
	 * depends on the API level
	 */
	final public static int getPlayButtonResource(boolean playing) {
		int playButton = 0;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
			// Android >= 5.0 uses the dark version of this drawable
			playButton = playing ? R.drawable.widget_pause : R.drawable.widget_play;
		} else {
			playButton = playing ? R.drawable.pause : R.drawable.play;
		}
		return playButton;
	}

	/**
	 * Returns TRUE if we should use the dark material theme,
	 * Returns FALSE otherwise - always returns FALSE on pre-5.x devices
	 */
	final private static boolean usesDarkTheme(Context context) {
		boolean useDark = false;
		if (usesHoloTheme() == false) {
			final int idx = getSelectedThemeIndex(context);
			final String[] variants = context.getResources().getStringArray(R.array.theme_variant);
			useDark = variants[idx].equals("dark");
		}
		return useDark;
	}

	/**
	 * Returns the user-selected theme index from the shared peferences provider
	 *
	 * @param context the context to use
	 * @return integer of the selected theme
	 */
	final private static int getSelectedThemeIndex(Context context) {
		SharedPreferences settings = PlaybackService.getSettings(context);
		String prefValue = settings.getString(PrefKeys.SELECTED_THEME, PrefDefaults.SELECTED_THEME);

		final String[] ids = context.getResources().getStringArray(R.array.theme_ids);
		for (int i = 0; i < ids.length; i++) {
			if (ids[i].equals(prefValue))
				return i;
		}
		// no theme found? return default theme.
		return 0;
	}

	/**
	 * Returns TRUE if this device uses the HOLO (android 4) theme
	 */
	final public static boolean usesHoloTheme() {
		return (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP);
	}

	/**
	 * Fetches a color resource from the current theme
	 */
	final public static int fetchThemeColor(Context context, int resId) {
		TypedArray a = context.obtainStyledAttributes(new int[]{resId});
		int color = a.getColor(0, 0);
		a.recycle();
		return color;
	}

	/**
	 * Returns the color to be used to draw the placeholder cover.
	 */
	final public static int[] getDefaultCoverColors(Context context) {
		if (usesHoloTheme()) // pre material device
			return new int[]{0xff000000, 0xff404040};

		int bg = fetchThemeColor(context, android.R.attr.colorBackground);
		int diff = 0x00171717 * (bg > 0xFF888888 ? -1 : 1);
		return new int[]{bg, bg + diff};
	}

}
